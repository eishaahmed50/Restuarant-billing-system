//          ************************************ " RESTURANT BILLING SYSTEM " **********************************************************


//   Made by >>>>>>>>>>>>>>>>>>>>   Eisha Ahmed (2018-CS-82) & Zainab Khalid (2018-CS-51)  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  MAIN FILE  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#include<iostream>

#include<string>

#include<stdlib.h>

#include"resturant.h"

#include <fstream>

#include <iomanip>

using namespace std;

int main()
{
s:
///////////////////////////////////object of Customer class/////////////////////////////////////
	customer c;
	
	c.getID();
	
	c.getPassword();
	
// checking Customer verification
	
	if(c.login()==1)   // if customer exist it login 
	{
  system("cls");
 	cout<<"You are succesfully login."<<endl;
	menu m;
///////////////////////////////////// object of menu class ///////////////////////////////////////////	
	
	m.loadMenu(); // for loading files 
	  
    m.getMenu(); // for printing all information in the file 
//////////////////////////////////// object of orderlist class////////////////////////////////
    orderlist o(m);

    o.getchoice();
//o.setorder();
/////////////////////////////////// object of user class ////////////////////////////////////////////
   
   user s(o);

s.saveuser();

s.loaduser();

system("cls");

//////////////////////////////////object of payment class//////////////////////////////////////////
payment p;

p.description();

p.getop();
////////////////////////////////object of bill clas//////////////////////////////////////////
bill b(o,m,s);

b.getBill();

b.resceipt();

}
else 

{
//if customer id or password does'nt exist

	cout<<"\nWe are enable to logging as CustomerID or Password not exist...!!"<<endl;
	
	cin.ignore();
	
	cout<<"Try again!"<<endl;
	
	goto s;
	
}

}

