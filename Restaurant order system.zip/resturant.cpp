//          ************************************ " RESTURANT BILLING SYSTEM " **********************************************************


//   Made by >>>>>>>>>>>>>>>>>>>>   Eisha Ahmed (2018-CS-82) & Zainab Khalid (2018-CS-51)  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  IMPLEMENTATION FILE  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#include<iostream>

#include<string>

#include<stdlib.h>

#include"resturant.h"

#include <fstream>

#include <iomanip>

	
			int l=1;
using namespace std;


 int x=0;
 
////////////////////////////////////////////Implementation of Customer Class/////////////////////////////////////////////////////////

		void customer:: getID()
	
	
		{
			
			
 cout<<"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< WELCOME TO THE 5 STAR RESTURANT >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"<<endl;
 
 // Getting Id
			
cout<<"                                 \"CHECKING IDENTIFICATION\""<<endl<<endl;
	
			cout << "Enter Customer ID: ";
			
			cin>>customers;
		
		}
		
// Getting Password
    	void customer::getPassword()
		
			{
			
			cout << "Enter Password: ";
			
			cin>>pass;
				
				
			}
//Customer Verification
	bool customer::login()
{
//Reading User file 				

  fstream file("UsersR.txt");
  
  string detail;
  int x=0;
  
  if (file.is_open())
  
   { 
  
   while (getline(file,detail,','))  //read customer Id after ',' read Password
     
	 {
      
	  customerID[x]=detail;
      
   	  getline( file,detail);
   	  
   	  password[x]=detail;
   	  
   	  x++;
   	  
     }
     
     
   }
  else
     {
  	// if User file does'nt Exist
  	
  	cout<<"Sorry, we are unable to run the program, as user data does not exist."<<endl;
	  }
	  
	  for(int i=0;i<10;i++)
	  {
	  
	if( (customers==customerID[i])==true && (pass==password[i])==true  )
  	{
	  
			  
				
				return 1;
			
		}
		else 
	
		return 0; // if customer Id or Password does'nt exist in file it returns 0
	
		
		}
		
	  }
 //Default constructor for customer class 
	customer::customer()
	{
	
		this->customers="None";
		this->pass="None";
	
	}
	
////////////////////////////////////////////Implementation of Menu Class/////////////////////////////////////////////////////////
void	menu::loadMenu()
{
//Read menu file

 ifstream file("menu.txt");
  
  string detail;
  
  string p[10];

  if (file.is_open())
  
   { 
   while (getline(file,detail,'.'))
     {
      
	  dishName[x]=detail;
      
   	  getline( file,detail);
   	  
      p[x]=detail;
   	
	   x++;
     }
}

  else
  
  {
  	

cout<<"Sorry, we are unable to get data, as menu data does not exist."<<endl; 
// if menu file does'nt exist
  
     
	 }
     
//read price file
int data[10];

ifstream myfile;
    
myfile.open("price.txt");


    for(int i = 0; i <10; i++)
    
       
	  
	  myfile >> data[i];
        
        cout<<endl;
    

      myfile.close();
    
for(int i=0;i<10;i++)
{
	price[i]=data[i];
}


}

// menu class Parametric constructor

  menu::menu(int p[],string d[])
  
  {
  	
  for(int i=0;i<10;i++)
  
  {

  	this->price[i]=p[i];      //Initiallizing price and dishname arrays
  	
  	this->dishName[i]=d[i];
  	
 
  }
  
  }
// Default Constructor of Menu class
menu::menu()

{


this->dishName[0]={"none"};

this->price[0]={0};



}
// Print menu list with prices

void menu::getMenu()

    { 

cout<<"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< WELCOME TO THE 5 STAR RESTURANT >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	<<endl;

    
	
	cout<<"************************************ Here is the List of Food Available Today **************************************\n"
	<<endl;
	
      cout<<setw(10)<<left<<left<<"Sr No"<<
      
      setw(30)<<"Dish Name"<<setw(50)<<left<<"Price"<<endl;
      
	  int l = 1;
	  
	  
	  cout<<"____________________________________________________________________________________________________________________"<<endl;
	  
	  
// for loop is used so that all dishes with prices entered are shown


	
	  for (int i = 0; i < 10; i++)
	  {
		 
		 
		 
		  cout << setw(10) << l << left <<setw(30)<<left<< dishName[i] <<
		  
			  setw(50)<<left<< price[i]<< endl;
			  
		  l++;
		  
	  
	  
	  } 
	  
	  cout<<"\n \nPress \"11\" when Your order is completed."<<endl;
	  // 11 will exit and get the paymengt option 
    }


////////////////////////////////////////////Implementation of orderlist Class/////////////////////////////////////////////////////////
int p=0;
		void    orderlist::getchoice()
		
		{
		

	int i=0;
	    
cout<<"\n"<<endl;
		
cout<<"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx Place your order Here xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n"<<endl;
		
	
			
		lo:
				
	cout<<"#########################################"<<" Order No: "<<l<<" #######################################"<<endl;
	
	
	
		cout<<"Enter your choice: ";                     //get choice from customer
	
		
	
		cin>>choice[i];
		 
		while(choice[i]!=11)
		
		{

			if(choice[i]>0&&choice[i]<11)
			
			{
			
	
			cout<<"Enter quantity of dishes : "; 
			
			                                                 //get quantity of dish
			cin>>quantity[i];
	
              i++;
              l++;

		again:


		cout<<"Want more food to Buy? Y/N : " ;
	
		cin>>more;                                        //if customer want to buy multiple items



while(more!='n'&&more!='N')                               // n mean no option


		{
			
						switch(more)
			  {
		    
			
			
			case 'y':
			case 'Y':	
		    goto lo;
			
			break;
	
			
			default:
			
			
				cout<<"Wrong option......Choose option 'y' for yes and 'n'  for no. "<<endl;
				
				cin.ignore();
				
				goto again;                       //if user enter other alphabets rather than 'y' or 'n'
			
				break;
				
				
		}		
		cout<<"exit";
		
		
		} 	
		break;
		
		 }
		   
		 else
       {

cout<<"Wrong choice..Choose again.."<<endl;

	goto lo;
	
        }
} 	
		}
		
	/*	void orderlist::setorder()
		{
	
			string l;
		
			cout<<"Your order is Selected..!!"<<endl;
		dish.dishName[orderlist.choice];
		
			cout<<"\n You have selected "<<l<<" and Quantity is "<<quantity<<endl;
			system("CLS");
		}*/
	//Default Constructor of oderlist class
	
		orderlist::orderlist()
		
		{
			
				for(int i=0;i<=10;i++)
				
 {
		
			
			this->quantity[i]=0;
	    	this->choice[i]=0;
	    	
	}
		
		}
		//parametric constructor of orderlist class
		
		orderlist::orderlist(int q[],int c[])
		
		{
		
		for(int i=0;i<10;i++)
			{
			
			this->quantity[i]=q[i];    //initializing quantity and choices
	    	this->choice[i]=c[i];
	 
	    	
	       }
		
		}
	//another peremetric cunstructor
			orderlist::orderlist(menu d):dish(d.price,d.dishName)
			{
				dish=d;
			}

		
////////////////////////////////////////////Implementation of payment Class/////////////////////////////////////////////////////////
void payment::getop( )
{

	
	p:
		cout<<"Choose your payment option: ";
	cin>>op;
	if(op=='C'||op=='c')
	{
	
	system("cls");                                                // 'c' for cash payment
	
	
	                                                              //'d' for Debit Card payment
	cout<<" You have selected \"Cash payment.\""<<endl;
	
}       
	else if(op=='D'||op=='d')
	{
		system ("cls");
	cout<<"\nYou have select \"Debit card payment.\""<<endl;	 
	}
	else 
	{
		cout<<"\nInvalid payment choice choose again.."<<endl;   // if customer enter other alphabets
	goto p;
	
	}
	
}
void payment::description()       //description for the customer 

{

cout<<"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"<<endl;

	cout<<"\n                                     \"PAYMENT OPTION\""<<endl;
	
	cout<<"Choose option: \n*For Cash enter 'C'\n*For Debit Card enter 'D'."<<endl;
	
	
}
//Default cunstroctor of payment class
payment::payment()

{
	this->op='C';                        // we set default value as cash
}


////////////////////////////////////////////Implementation of bill Class/////////////////////////////////////////////////////////

void bill::getBill( )
{
	int sum=0;
	
	for(int i=0;i<4;i++)
	
	{
sum=sum+ord.quantity[i]*men.price[ord.choice[i]-1]; 
                                                       //calculating total bill
}
this->total=sum;
}

// getting resciept of the items 

void bill::resceipt()
{

		cout<<"\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"<<endl;
	   
	    cout<<"                                              \"RECEIPT\""<<endl;
	
		cout<<"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"<<endl;
		  
		  
		  
		  cout<<"ORDER LIST: "<<endl<<endl;
		 cout<<"____________________________________________________________________________________________________________________"<<endl;
		 
		 
		 
		 cout<<setw(10)<<left<<left<<"Sr No"<<
      setw(30)<<"Dish Name"<<setw(50)<<left<<"Quantity"<<setw(20)<<left<<"Price"<<endl;
      
	  int l = 1;
	  cout<<"____________________________________________________________________________________________________________________"<<endl;
	  
	  
	    for (int i = 0; i < 4; i++)
	  {
		 
		  cout << setw(10) << l << left <<setw(30)<<left<<men.dishName[ord.choice[i]-1 ]<<
		  
			  setw(50)<<left<<ord.quantity[i]<<left<<"RS "<<men.price[ord.choice[i]-1]<<endl;  
		  l++;
		  
		  //to print all the ordered food with its quantity
	  }
	  cout<<"____________________________________________________________________________________________________________________"<<endl; 
	cout<<"\n\nTOTAL:                                                                                        RS "<<total<<endl;
		cout<<"____________________________________________________________________________________________________________________"<<endl;

	cout<<"                                                                                      Thanks For Coming.....Good Bye :)"<<endl;
}


//Default cunstructor of bill class 

bill::bill()
{
	this->total=0;
}
//parametric cunstructor of bill class


bill::bill(orderlist o,menu m,user u):men(m.price,m.dishName),ord(o.choice,o.quantity),u(u.select)
{
	  
	ord=o;
	men=m;         //initializing price,dishname,quantity and selected item arrays
    u=u;
}

// selected item by customer saving in file 

void user::saveuser()
{
    
	ofstream fout;
	
	fout.open("SaveUser.txt");   //creating file
	
	
	for(int i=0;i<4;i++)
	
	
	{
		fout<<select.choice[i]<<'_'<<select.quantity[i]<<endl;  //inserting choice and selected quantity by customer
		
		
	}
	
	
	fout.close(); //file close

}

//parametric cunstructor of user class

user::user(orderlist o):select(o.choice,o.quantity)

{
	o=select;     //initializing arrays of choice and quantity
	
	
}


//default cunstructor of user class

user::user()
{
	
	for(int i=0;i<4;i++)
	
	{
	
	this->select.choice[i]=0;
	this->select.quantity[i]=0;
	
	
}

}

//loading data frome SaveUser file to get all values in there corresponding arrays


void user::loaduser()
{
	ifstream file("SaveUser.txt");
	
  int x=0;
  
int detail;

 int p[10];
 
char character;

  if (file.is_open())
   { 
   while (character=='_')                     
   
   //          first load   dishName in array and after '_' load quantity array
     
	 {
      
	  
	  order.dishName[x]=detail;
      
      file >>   order.dishName[x];
      
     select.quantity[x]=detail;
       x++;
       
       
       cout<<endl;
}
      
 }

 else 
    {
  	
  	cout<<"file not exist"<<endl;
  	
  	//if save user file does'nt exist
   } 
	
}
