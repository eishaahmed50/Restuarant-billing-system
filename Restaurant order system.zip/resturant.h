//          ************************************ " RESTURANT BILLING SYSTEM " **********************************************************


//   Made by >>>>>>>>>>>>>>>>  Eisha Ahmed (2018-CS-82) & Zainab Khalid (2018-CS-51)& Sana Aslam(2018-CS-68)  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Header File  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#include<iostream>

#include<string>

#include<stdlib.h>

#include <fstream>

#include <iomanip>

// customer and payment class are both independent class no composition
using namespace std;
class customer
{
	private:
		string customers;
		string pass;
        string customerID[10];
	    string password[10];
	public:
	    void getID( );
		void getPassword( );
     	bool  login();
		customer();
	
};


class menu
{
public:
	
	
  string dishName[10];
  int price[10];
  void loadMenu();
  void getMenu();
  menu(); 
  menu(int p[],string d[]);
		
};



class orderlist
{
 public:
	int quantity[10];
	int choice[10];
	char more;
    menu dish;
public:

	void getchoice();
	//	void setorder();
	orderlist(int q[] ,int c[]);
	orderlist(menu d);
	orderlist();
	
};





class payment
{
private:
char op;

public:
	
void description();
void getop();
payment();

};




class user
{
	public:
	menu order;
	orderlist select;
	
	void saveuser();
     void loaduser();
	user(orderlist o);
	user();
	
};
class bill
{
private:
user u;
orderlist ord;
menu men;
int total;

public:
void getBill( );
void resceipt();
bill();
bill(orderlist o,menu m,user u);

};
